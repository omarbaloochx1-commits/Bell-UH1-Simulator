# Bell UH-1H Flight Sim Pro

Expanded Android 2D helicopter game prototype.

Features: cold-and-dark startup, engine spool-up, rotor RPM, altitude, airspeed, VSI, torque and fuel instruments; collective, throttle, cyclic pitch/roll and pedals; simplified inertia-based flight dynamics, translational lift, ground effect, yaw and touchdown checks; animated scrolling landscape; first mission (start, takeoff, navigate to landing zone, land); in-game pilot guide; optional synthesized rotor sound.

## Build
Upload this ZIP to your GitHub repository, run your existing Extract ZIP and Build APK workflow, then download the APK artifact.

Java and Kotlin compilation targets are both set to Java 17.

Note: game-oriented approximation, not a certified aircraft trainer or real UH-1H operating manual.


Animation update: replaced the previous helicopter animation with the supplied 12-frame PNG sequence (transparent RGBA, 640x360). The main rotor and tail rotor remain part of the same animation.


CLEAN ANIMATION BUILD: uses only the 12 replacement frames in app/src/main/assets/heli_frames_v4/. The previous heli_frames directory is not included.
